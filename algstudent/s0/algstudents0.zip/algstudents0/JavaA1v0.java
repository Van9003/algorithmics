import java.util.ArrayList;
import java.util.List;

public class JavaA1v0 {
	public static Integer[] listadoPrimos(int n) {
		List<Integer> primes = new ArrayList<>();
		for(int i = 2;i<=n;i++) {
			if(new JavaA1v1().primoA1(i)) {
				primes.add(i);
			}
		}
		return primes.toArray(new Integer[primes.size()]);
	}
}
