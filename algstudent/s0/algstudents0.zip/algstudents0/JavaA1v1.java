
public class JavaA1v1 {
	public static boolean primoA1(int n) {
		for(int i=2;i<=n;i++) {
			if(n%i==0) {
				return false;
			}
		}
		return true;
	}
}
