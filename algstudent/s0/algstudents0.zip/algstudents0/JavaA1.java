public class JavaA1 {
	public static void main(String[] args) {
		int n=1000;
		for(int i=0;i<7;i++) {
			long t1 = System.currentTimeMillis();
			Integer[] primes = new JavaA1v0().listadoPrimos(n);
			long t2 = System.currentTimeMillis();
			System.out.println("n = "+n+"***time = " + (t2-t1) +"milliseconds");
			n=n*2;
		}
	}
}
